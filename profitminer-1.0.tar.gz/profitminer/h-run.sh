#!/usr/bin/env bash

. h-manifest.conf

./profitminer $(< ./$CUSTOM_NAME.conf) --api-port=${CUSTOM_API_PORT} --log-file=$CUSTOM_LOG_BASENAME.log
