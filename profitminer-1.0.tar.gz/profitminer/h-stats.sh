stats_raw=`curl --connect-timeout 2 --max-time $API_TIMEOUT --silent --noproxy '*' http://127.0.0.1:63002`
if [[ $? -ne 0 || -z $stats_raw ]]; then
  echo -e "${YELLOW}Failed to read stats from http://127.0.0.1:63002"
else
  local temp=$(jq "[.temp$nvidia_indexes_array]" <<< $gpu_stats)
	local fan=$(jq "[.fan$nvidia_indexes_array]" <<< $gpu_stats)
	local ver=`echo $stats_raw | jq -c -r ".version"`
  local bus_numbers=$(echo $stats_raw | jq -r ".devices[].bus_id" |  jq -sc .)
  local algo=`echo $stats_raw | jq -c -r ".algos[0].name"`
  local ac=`echo $stats_raw | jq -c -r ".algos[0].total_accepted_shares"`
  local inv=`echo $stats_raw | jq -c -r ".algos[0].total_rejected_shares"` 
  local uptime=`echo $stats_raw | jq -c -r ".uptime_seconds"`

  units="hs"
  khs=`echo $stats_raw | jq -r '.algos[0].total_hashrate' | awk '{print $1/1000}'`
  
  local num_algos=`echo $stats_raw | jq -r '.num_algos'`

  if [[ $num_algos -gt 1 ]]; then
    units2="hs"
    khs1=$khs
    khs2=`echo $stats_raw | jq -r '.algos[1].total_hashrate' | awk '{print $1/1000}'`
    algo1=$algo
    algo2=`echo $stats_raw | jq -c -r ".algos[1].name"`
    ac2=`echo $stats_raw | jq -c -r ".algos[1].total_accepted_shares"`
    inv2=`echo $stats_raw | jq -c -r ".algos[1].total_rejected_shares"`
    stats=$(jq --arg ac "$ac" --arg inv "$inv" \
            --arg algo "$algo" \
            --arg ver "$ver" --arg uptime "$uptime" \
            --argjson fan "$fan" --argjson temp "$temp" \
            --argjson bus_numbers "$bus_numbers" \
            --arg hs_units "$units" \
            --arg hs_units2 "$units2" \
            --arg ac2 "$ac2" --arg inv2 "$inv2" \
            --arg algo2 "$algo2" \
            --arg total_khs "$khs" \
            --arg total_khs2 "$khs2" \
            '{$total_khs, hs: .algos[0].hashrates, $hs_units,  $temp, $fan, $algo, $uptime, ar: [$ac, $inv], $bus_numbers, $ver, $total_khs2, $hs_units2, hs2: .algos[1].hashrates, ar2:[$ac2, $inv2], $algo2}' <<< "$stats_raw")
  else
    stats=$(jq --arg ac "$ac" --arg inv "$inv" \
            --arg algo "$algo" \
            --arg ver "$ver" --arg uptime "$uptime" \
            --argjson fan "$fan" --argjson temp "$temp" \
            --argjson bus_numbers "$bus_numbers" \
            --arg units "$units" \
            '{hs: .algos[].hashrates, hs_units: $units,  $temp, $fan, $algo, $uptime, ar: [$ac, $inv], $bus_numbers, $ver}' <<< "$stats_raw")

  fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
fi
